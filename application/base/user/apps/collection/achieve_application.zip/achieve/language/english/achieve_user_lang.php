<?php
$lang["storage"] = "Achieve";


$lang["actions"] = "Actions";

$lang["delete"] = "Delete";

$lang["add_to_category"] = "Add to Employee";

$lang["remove_from_category"] = "Remove from Employee";

$lang["categories"] = "Employees";

$lang["please_select_a_media"] = "Please select at least a file.";

$lang["create_category"] = "Create Employee";

$lang["save"] = "Save";

$lang["enter_category_name"] = "Enter the employee's name";

$lang["please_enter_valid_category"] = "Please enter the employee's name.";

$lang["category_was_saved"] = "Employee was saved successfully";

$lang["category_was_not_saved"] = "Employee wasn't saved successfully";

$lang["select_a_category"] = "Select a Employee";

$lang["please_select_a_category"] = "Please select a employee.";

$lang["error_occurred"] = "An error occurred while processing your request.";

$lang["media_added_to_category"] = " media files added to a employee.";

$lang["media_removed_from_category"] = " media files removed from the selected category.";
$lang["delete_category"] = "Delete Employee";

$lang["employee_was_deleted"] = "The employee was deleted successfully.";

$lang["employee_was_not_deleted"] = "The employee was not deleted successfully.";

$lang["no_files_found"] = "No files found.";

$lang["upload_files"] = "Upload Files";

$lang["import_urls"] = "Import From Url";

$lang["enter_urls_one_per_line"] = "Enter image's urls(PNG, GIF or JPEG), one per line ...";

$lang["download"] = "Download";

$lang["images_were_saved_successfully"] = " images were saved successfully.";

$lang["file_upload"] = "File Upload";

$lang["drag_drop_files"] = "Drag files here or <a href='#'>browse</a> to upload";

$lang["load_more"] = "Load more";

$lang["no_photos_videos_uploaded"] = "No photos or videos uploaded yet.";

$lang["all_categories"] = "All Employees";